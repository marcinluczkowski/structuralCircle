[![DOI](https://zenodo.org/badge/574263139.svg)](https://zenodo.org/badge/latestdoi/574263139)
# structuralCircle
Sustainable design from used structural elements. A project about building design from used elements in Grasshopper and Rhino. 

Colab notebook with the mapping algorithms:
https://colab.research.google.com/drive/1BRBxFhya6xCnV-flAPq-Ro8zkxuSnnhC?usp=sharing
