import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
#sys.path.insert(0, os.path.abspath(os.path.join(sys.path[0], '..')))
from src import(
    LCA, 
    matching, 
    helper_methods,
    
)
from src.matching import run_matching
