import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
sys.path.insert(2, os.path.abspath(os.path.join(sys.path[0], 'src')))
sys.path.insert(3, os.path.abspath(os.path.join(sys.path[0], 'data')))

import helper_methods as hm
from matching import run_matching

# Define constants
constants = {
    "TIMBER_GWP": 28.9,       # based on NEPD-3442-2053-EN
    "TIMBER_REUSE_GWP": 2.25,        # 0.0778*28.9 = 2.25 based on Eberhardt
    "TRANSPORT_GWP": 96.0,    # TODO kg/m3/t based on ????
    "TIMBER_DENSITY": 491.0,  # kg, based on NEPD-3442-2053-EN
    "STEEL_GWP": 800, #Random value
    "STEEL_REUSE_GWP": 4, #Random value
    "VALUATION_GWP": 0.6, #In kr:Per kg CO2, based on OECD
    "TIMBER_PRICE": 435, #Per m^3 https://www.landkredittbank.no/blogg/2021/prisen-pa-sagtommer-okte-20-prosent/
    "TIMBER_REUSE_PRICE" : 100, #Per m^3, Random value
    "STEEL_PRICE": 500, #Per m^2, Random value
    "STEEL_REUSE_PRICE": 200, #Per m^2, Random value
    "PRICE_TRANSPORTATION": 3.78, #Price per km per tonn. Derived from 2011 numbers on scaled t0 2022 using SSB
    "STEEL_DENSITY": 7850,
    ########################
    "Project name": "Sognsveien 17",
    "Metric": "GWP",
    "Algorithms": ["bipartite", "greedy_single", "greedy_plural", "sci_milp"],
    "Include transportation": False,
    "Demand file location" : r"data\CSV\simple_demand.csv",
    "Supply file location" : r"data\CSV\simple_supply.csv",
    "Site latitude": "59.94161606",
    "Site longitude": "10.72994518",
    "constraint_dict": {'Area' : '>=', 'Moment of Inertia' : '>=', 'Length' : '>=',}
}


# Read data and add necessary information
print(f"File path for simple case: {os.path.dirname(__file__)}")
rel_path = '\\'.join(os.path.relpath(__file__, start = os.curdir).split('\\')[:-2]) # remove the last two levels of this scripts path
demand_path = os.path.join(rel_path, constants['Demand file location']) # Join the relative path to the static part of path
supply_path = os.path.join(rel_path, constants['Supply file location']) # Join the relative path to the static part of path

# Read data and add necessary information
supply = hm.import_dataframe_from_file(supply_path, index_replacer = "S")
demand = hm.import_dataframe_from_file(demand_path, index_replacer = "D")
# add material to all elements
supply['Material'] = "Timber C30"
demand['Material'] = "Timber C30"
supply = hm.add_necessary_columns_pdf(supply, constants)
demand = hm.add_necessary_columns_pdf(demand, constants)

#
constraint_dict = constants["constraint_dict"]
score_function_string = hm.generate_score_function_string(constants)
run_string = hm.generate_run_string(constants)
result = eval(run_string)

simple_pairs = hm.extract_pairs_df(result)
simple_results = hm.extract_results_df(result, constants["Metric"])

print("Simple pairs:")
print(simple_pairs)

print()
print("Simple results")
print(simple_results)

# Calculate volumes
print("\nChange in Volume [%]\n")
dem = result[0]['Match object'].demand
sup = result[0]['Match object'].supply

indices = list(dem.index)
simple_el_ids = simple_pairs.mask(simple_pairs.isna(), indices, axis = 0) # replace NaN values with the intital index.
areas = simple_el_ids.applymap(lambda el : dem.Area[el] if 'D' in el else sup.Area[el]) # Find the correct areas for each matching.
volumes = areas.apply(lambda row: row * dem.Length.to_numpy(), axis = 0) # Get the volume by calculating the correct area with the length of demand elements.
total_volumes = volumes.sum() # Sum each column to get total volumes. 
initial_volume = sum(dem.Area*dem.Length)

ratios = round((total_volumes - initial_volume) / initial_volume, 2) * 100


print(ratios)