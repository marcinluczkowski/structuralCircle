from setuptools import setup, find_packages

with open(r"README.md", 'r') as f:
    long_description = f.read()

setup(    
    version = "0.0.1",
    name = 'elementmatcher',
    description = "Package for macthing reclaimed elements.",
    long_description= long_description,
    long_description_content_type = "text/markdown",
    author = 'sverremh',
    package_dir={'':'app'},
    packages = find_packages(where='app'),
    include_package_data=True,
    package_data={'': ['data/CSV/*.csv']},
    license="MIT",
    classifiers = [
    "Programming Language :: Python :: 3.11",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    ],
    install_requires = ['numpy', 'pandas', 'matplotlib', 'requests', 'ortools','scipy',
                        'igraph', 'pygad', 'numexpr', 'fpdf',  'folium', 'selenium',],
    extras_require = {
        'dev': ['pytest>=7.0', 'twine>=4.0.2']
    },
    python_requires = ">=3.11",

)





